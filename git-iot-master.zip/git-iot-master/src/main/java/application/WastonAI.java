//package application;
//
//public class WastonAI {
//
//	public static void main(String[] args) {
//		
//		var VisualRecognitionV3 = require('watson-developer-cloud/visual-recognition/v3');
//
//		var visualRecognition = new VisualRecognitionV3({
//		  version: '2018-03-19',
//		  iam_apikey: 'By62W_ehSwS2_zEXPdH2EvCQF_Hk6LaE_0JxkqOR34ht'
//		});
//
//		VisualRecognition visualRecognition = new VisualRecognition("2018-03-19", options);
//
//		DetectFacesOptions detectFacesOptions = new DetectFacesOptions.Builder()
//		  .url("https://watson-developer-cloud.github.io/doc-tutorial-downloads/visual-recognition/Ginni_Rometty_at_the_Fortune_MPW_Summit_in_2011.jpg");
//		  .build();
//		DetectedFaces result = visualRecognition.detectFaces(detectFacesOptions).execute();
//		System.out.println(result);
//
//
//
//	}
//
//}
