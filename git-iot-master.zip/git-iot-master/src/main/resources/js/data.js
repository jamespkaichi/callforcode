var datajson = [
    {"id":"001", "things":"Food","type":"BigTent","locationone":17.409,"locationtwo":48.9097},
    {"id":"002", "things":"Stretcher","type":"BigTent","locationone":17.419,"locationtwo":48.9187},
    {"id":"003", "things":"Bandage","type":"SmallTent","locationone":17.429,"locationtwo":48.9157},
    {"id":"004","things":"Drugs","type":"BigTent","locationone":17.439,"locationtwo":48.9127},
    {"id":"005","things":"Stretcher","type":"SmallTent","locationone":17.449,"locationtwo":48.9177}
]